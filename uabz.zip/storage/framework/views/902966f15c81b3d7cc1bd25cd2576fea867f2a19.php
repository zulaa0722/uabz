<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-12">
      <div class="row">
          <div class="col-xl-8">
              <div class="card">
                <div  class="card-body">
                  <h4 Class="text-center">Малын махны төрөл</h4>
                  <table id="cattleDB" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                      <thead>
                        <tr>
                          <th>№</th>
                          <th>Малын нэр</th>
                          <th>Хонин толгойд шилжүүлэх коффициент</th>
                        </tr>
                      </thead>
                      <tbody>
                        <td></td>
                        <td></td>

                      </tbody>
                    </table>
                    <button class="btn btn-primary" type="button" name="button" id="btnSectorAdd">Нэмэх</button>
                    <button class="btn btn-warning" type="button" name="button" id="btnSectorEdit">Засах</button>
                    <button class="btn btn-danger" type="button" name="button" id="btnCattleDelete">Устгах</button>
                  </div>
                </div>
            </div>
        </div>
      </div>
    </div>
<?php echo $__env->make('Cattle.CattleNew', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Cattle.CattleEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url("public/uaBCssJs/datatableCss/datatables.min.css")); ?>">
  <style media="screen">
#cattleDB tbody tr.selected {
  color: white;
  background-color: #8893f2;
}
#cattleDB tbody tr{
cursor: pointer;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/datatables.min.js")); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/jszip.min.js")); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/pdfmake.min.js")); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/datatables.init.js")); ?>"></script>

  <script type="text/javascript">
  var dataRow = "";
  var csrf = "<?php echo e(csrf_token()); ?>";
  var getCattle = "<?php echo e(url("/getCattle")); ?>";
  var cattleNew = "<?php echo e(url("/cattle/insert")); ?>";
  var cattleEditUrl = "<?php echo e(url("/cattle/edit")); ?>";
  var cattleDeleteUrl = "<?php echo e(url("/cattle/delete")); ?>";

  $(document).ready(function(){
    var table = $('#cattleDB').DataTable({
      "language": {
              "lengthMenu": "_MENU_ мөрөөр харах",
              "zeroRecords": "Хайлт илэрцгүй байна",
              "info": "Нийт _PAGES_ -аас _PAGE_-р хуудас харж байна ",
              "infoEmpty": "Хайлт илэрцгүй",
              "infoFiltered": "(_MAX_ мөрөөс хайлт хийлээ)",
              "sSearch": "Хайх: ",
              "paginate": {
                "previous": "Өмнөх",
                "next": "Дараахи"
              },
              "select": {
                  rows: ""
              }
          },
          select: {
            style: 'single'
        },
          "processing": true,
          "serverSide": true,
          "stateSave": true,
          "ajax":{
                   "url": getCattle,
                   "dataType": "json",
                   "type": "POST",
                   "data":{
                        _token: csrf
                      }
                 },
          "columns": [
            { data: "id", name: "id",  render: function (data, type, row, meta) {
          return meta.row + meta.settings._iDisplayStart + 1;
      }  },
            { data: "cattleName", name: "cattleName"},
            { data: "ratio", name: "ratio"}

            ]
        });

        $('#cattleDB tbody').on( 'click', 'tr', function () {
          if ( $(this).hasClass('selected') ) {
              $(this).removeClass('selected');
              dataRow = "";
          }else {
              table.$('tr.selected').removeClass('selected');
              $(this).addClass('selected');
              var currow = $(this).closest('tr');
              dataRow = $('#cattleDB').DataTable().row(currow).data();
          }
          });
  });
  </script>

<script src="<?php echo e(url("public/js/Cattle/CattleNew.js")); ?>"></script>
<script src="<?php echo e(url("public/js/Cattle/CattleEdit.js")); ?>"></script>
<script src="<?php echo e(url("public/js/Cattle/CattleDelete.js")); ?>"></script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\uabz\resources\views/Cattle/Cattle.blade.php ENDPATH**/ ?>