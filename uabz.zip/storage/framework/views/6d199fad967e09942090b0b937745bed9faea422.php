<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo e(url('public/css/zam_login.css')); ?>" rel="stylesheet">

    <link rel="icon" type="image/x-icon" href="<?php echo e(url('public/images/gsmaf_logo.ico')); ?>"/>
    <!-- jQuery -->
    <script src="<?php echo e(url('public/vendors/jquery/dist/jquery.min.js')); ?>"></script>
    <!-- Bootstrap -->
    <script src="<?php echo e(url('public/vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <link href="<?php echo e(url('public/vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">



    <!--Zagvarlag alert-->
    <link rel="stylesheet" href="<?php echo e(asset('public/z-alert/css/alertify.core.css')); ?>" />
	  <link rel="stylesheet" href="<?php echo e(asset('public/z-alert/css/alertify.default.css')); ?>" />
    <script src="<?php echo e(asset('public/z-alert/js/alertify.min.js')); ?>"></script>
    <!--Zagvarlag alert-->

    <title>Үндэсний аюулгүй байдал</title>
  </head>
  <body>

    <div id="content" class="col-md-4 col-md-offset-4">
      <?php echo $__env->yieldContent("content"); ?>

    </div>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\uabz\resources\views/layouts/layout_login.blade.php ENDPATH**/ ?>