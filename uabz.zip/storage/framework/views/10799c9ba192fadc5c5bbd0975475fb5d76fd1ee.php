<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-12">
      <div class="row">
          <div class="col-xl-12">
            <div class="card">
              
              <div  class="card-body">
                <div class="col-md-6">
                  <div class="form-group row">
                    <label class="col-md-6 col-form-label text-md-right">Аймгаа сонгоно уу=></label>
                    <div class="col-md-6">
                      <select post-url="<?php echo e(url("/get/dangered/syms/by/provID")); ?>" class="form-control" id="cmbProv" name="">
                        <option value="0">Сонгоно уу</option>
                        <?php $__currentLoopData = $provs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($prov->provID); ?>"><?php echo e($prov->provName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 d-none" id="divSums">
                  <div class="form-group row">
                    <label class="col-md-6 col-form-label text-md-right">Сумаа сонгоно уу=></label>
                    <div class="col-md-6">
                      <select class="form-control" id="cmbSum" name="">
                        <option value="0">Сонгоно уу</option>
                      </select>
                    </div>
                  </div>
                </div>

                <h4 class="text-center"><span class="text-success" id="lblProv"></span> <span class="text-success" id="lblSum"></span> малын тоо толгойны мэдээлэл</h4>

                <table post-url="<?php echo e(url("/get/log/cattles")); ?>" id="cattleDB" class="table table-striped table-bordered" style="border-collapse: collapse; border-spacing: 0; width: 40%;">
                  <thead>
                    <tr>
                      <th rowspan="2">№</th>
                      <th rowspan="2">Огноо</th>
                      <?php $__currentLoopData = $cattles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cattle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th style="text-align:center;" colspan="3"><?php echo e($cattle->cattleName); ?></th>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <tr>
                      <?php $__currentLoopData = $cattles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cattle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th>Тоо</th>
                        <th>Хонин толгой</th>
                        <th>Кг</th>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                  </thead>
                  <tbody>
                  </tbody>
                </table>
                <button class="btn btn-primary" type="button" name="button" id="btnAddModalOpen">Нэмэх</button>
                <button class="btn btn-warning" type="button" name="button" id="btnEditModalOpen">Засах</button>
                <button class="btn btn-danger" type="button" name="button" id="btnLogCattleDelete">Устгах</button>
              </div>
              
            </div>
          </div>
        </div>
      </div>
    </div>
<?php echo $__env->make('logCattle.logCattleNew', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('logCattle.logCattleEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url("public/uaBCssJs/datatableCss/datatables.min.css")); ?>">
  <link rel="stylesheet" href="<?php echo e(url("public/uaBCssJs/datatableCss/datatables.min.css")); ?>">
    <style media="screen">
      #cattleDB tbody tr.selected {
        color: white;
        background-color: #8893f2;
      }
      #cattleDB tbody tr{
        cursor: pointer;
      }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/datatables.min.js")); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/jszip.min.js")); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/pdfmake.min.js")); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/datatables.init.js")); ?>"></script>

  <script type="text/javascript">
    var table="";
    var sheepKG = parseFloat("<?php echo e(ConstantVariables::sheepKG); ?>");
    var cattlesCols = <?php echo json_encode($cattles); ?>;
    console.log(cattlesCols);
    $(document).ready(function(){
      table = $('#cattleDB').DataTable({
        "language": {
          "lengthMenu": "_MENU_ мөрөөр харах",
          "zeroRecords": "Хайлт илэрцгүй байна",
          "info": "Нийт _PAGES_ -аас _PAGE_-р хуудас харж байна ",
          "infoEmpty": "Хайлт илэрцгүй",
          "infoFiltered": "(_MAX_ мөрөөс хайлт хийлээ)",
          "sSearch": "Хайх: ",
          "paginate": {
            "previous": "Өмнөх",
            "next": "Дараахи"
          },
          "select": {
            rows: ""
          }
        },
        select: {
          style: 'single'
        },
        "stateSave": true,
        "orderCellsTop": true,
        "fixedHeader": true,
        "scrollX":true,
        "processing": true,
        "scrollX": true,
        "order": [[1, 'asc']],
         "columnDefs": [{
            "targets": "_all",
            "orderable": false
         }],
      });
    });
  </script>
  <script src="<?php echo e(url("public/js/logCattle/logCattleShow.js")); ?>"></script>
  <script src="<?php echo e(url("public/js/logCattle/logCattleNew.js")); ?>"></script>
  <script src="<?php echo e(url("public/js/logCattle/logCattleEdit.js")); ?>"></script>
  <script src="<?php echo e(url("public/js/logCattle/logCattleShow.js")); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\uabz\resources\views/LogCattle/logCattleShow.blade.php ENDPATH**/ ?>