    <!doctype html>
    <html lang="en">
        <head>
            <meta charset="utf-8" />
            <title>Үндэсний аюулгүй байдлын зөвлөл</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
            <meta content="Themesbrand" name="author" />
            <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
            <!-- App favicon -->
             <link rel="shortcut icon" href="<?php echo e(url("public/images/uabz_icon.ico")); ?>">

             <link href="<?php echo e(url("public/uaBCssJs/sweet-alert/sweetalert2.min.css")); ?>" id="bootstrap-dark" rel="stylesheet" type="text/css" />


            
            <!-- App css -->
            <link href="<?php echo e(url("public/uaBCssJs/css/bootstrap-dark.min.css")); ?>" id="bootstrap-dark" rel="stylesheet" type="text/css" />
            <link href="<?php echo e(url("public/uaBCssJs/css/bootstrap.min.css")); ?>" id="bootstrap-light" rel="stylesheet" type="text/css" />
            <link rel="stylesheet" href="<?php echo e(url("/public/uaBCssJs/css/icons.min.css")); ?>">
            <link href="<?php echo e(url("public/uaBCssJs/css/app-rtl.min.css")); ?>" id="app-rtl" rel="stylesheet" type="text/css" disbaled="" />
            <link href="<?php echo e(url("public/uaBCssJs/css/app-dark.min.css")); ?>" id="app-dark" rel="stylesheet" type="text/css" />
            <link href="<?php echo e(url("public/uaBCssJs/css/app.min.css")); ?>" id="app-light" rel="stylesheet" type="text/css" />


            <link href="<?php echo e(url("public/css/uabz_css.css")); ?>" id="app-light" rel="stylesheet" type="text/css" />


            <!--Zagvarlag alert-->
            <link rel="stylesheet" href="<?php echo e(asset('public/z-alert/css/alertify.core.css')); ?>" />
            <link rel="stylesheet" href="<?php echo e(asset('public/z-alert/css/alertify.default.css')); ?>" />
            <script src="<?php echo e(asset('public/z-alert/js/alertify.min.js')); ?>"></script>
            <!--Zagvarlag alert-->
            <?php echo $__env->yieldContent('css'); ?>

            <style media="screen">
              #headerID{
                background-image: url(<?php echo e(url("public/assets/images/bg_img.jpg")); ?>);
                background-size: 100% 100%;
                background-repeat: no-repeat;
              }
            </style>


          </head>



        <body data-sidebar="dark">
                <div id="preloader">
            <div id="status">
                <div class="spinner-chase">
                    <div class="chase-dot"></div>
                    <div class="chase-dot"></div>
                    <div class="chase-dot"></div>
                    <div class="chase-dot"></div>
                    <div class="chase-dot"></div>
                    <div class="chase-dot"></div>
                </div>
            </div>
        </div>
              <!-- Begin page -->
              <div id="layout-wrapper">
                <header id="page-topbar">
                    <div class="navbar-header" id="headerID">

                        <div class="d-flex">
                            <!-- LOGO -->
                            <div class="navbar-brand-box">
                                <a href="#" class="logo logo-dark" style="cursor:default;">
                                    <span class="logo-sm">
                                      <img src="<?php echo e(url("public/assets/images/logo.svg")); ?>" alt="" height="22">
                                    </span>
                                    <span class="logo-lg">
                                        <img src="<?php echo e(url("public/assets/images/logo-dark.png")); ?>" alt="" height="30">
                                    </span>
                                </a>

                                <a href="#" class="logo logo-light"  style="cursor:default;">
                                    <span class="logo-sm">
                                        <img src="<?php echo e(url("public/assets/images/logo-sm.png")); ?>" alt="" height="22">
                                    </span>
                                    <span class="logo-lg">
                                        <img src="<?php echo e(url("public/assets/images/left-side-menu-logo.png")); ?>" alt="" height="55">
                                    </span>
                                </a>
                            </div>
                            <button type="button" style="background-color:#2f2f2f;" class="btn btn-sm px-3 font-size-24 header-item waves-effect" id="vertical-menu-btn">
                                <i class="mdi mdi-menu"></i>
                            </button>
                        </div>

                        <div class="d-flex" style="height: 100%; background-color: #b1d8ff; opacity:0.8;">
                              <!-- App Search-->
                            <div class="dropdown d-none d-lg-inline-block">
                                <button type="button" class="btn header-item noti-icon waves-effect" data-toggle="fullscreen">
                                    <i class="mdi mdi-fullscreen"></i>
                                </button>
                            </div>



                            <div class="dropdown d-inline-block">
                                <button type="button" class="btn header-item waves-effect" id="page-header-user-dropdown"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img class="rounded-circle header-profile-user" src="<?php echo e(url("public/assets/images/logo-top.png")); ?>"
                                        alt="Header Avatar">
                                </button>

                                <div class="dropdown-menu dropdown-menu-right">
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item text-danger" href="javascript:void();" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                        <i class="bx bx-power-off font-size-17 align-middle mr-1 text-danger"></i>
                                        Гарах
                                    </a>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    </form>
                                </div>
                            </div>
                            <div class="d-inline-block">
                              <button type="button" disabled class="btn header-item">
                                  <h4 style="opacity:1; color: black; font-weight: bold;"><?php echo e(Auth::user()->name); ?></h4>
                                  
                              </button>
                            </div>

                            <div class="dropdown d-inline-block">
                                <button type="button" class="btn header-item noti-icon right-bar-toggle waves-effect">
                                    <i class="mdi mdi-settings-outline"></i>
                                </button>
                            </div>

                        </div>
                    </div>
                </header>            <!-- ========== Left Sidebar Start ========== -->
    <div class="vertical-menu">

    <div data-simplebar class="h-100">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title">Үндсэн хэсэг</li>

                <li>
                    <a href="<?php echo e(url("/mongolia/maps")); ?>" class="waves-effect">
                        <i class="ti-location-pin"></i>
                        
                        <span>Монгол Улс</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url("/foodReserve")); ?>" class="waves-effect">
                        <i class="ti-package"></i>
                        
                        <span>Хүнсний нөөц</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url("/reports")); ?>" class="waves-effect">
                        <i class="ti-bar-chart"></i>
                        
                        <span>Тайлан</span>
                    </a>
                </li>

                <li class="menu-title">Бүртгэлийн хэсэг</li>

                <li>
                <a href="<?php echo e(url("/survey/list")); ?>" >
                    <i class="dripicons-to-do"></i>
                    <span>Судалгаа</span>
                </a>

            </li>
            <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="ti-map-alt"></i>
                <span>Бүсчлэл</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(url("/sector/show")); ?>">Бүс</a></li>
                <li><a href="<?php echo e(url("/province/show")); ?>">Аймаг</a></li>
                <li><a href="<?php echo e(url("/sym/show")); ?>">Сум</a></li>
                <li><a href="<?php echo e(url("/pop/show")); ?>">Хүн ам</a></li>
            </ul>
            </li>

            <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="ti-package"></i>
                <span>Мах</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(url("/cattle/show")); ?>">Малын төрөл</a></li>
                <li><a href="<?php echo e(url("/cattleQntt/show")); ?>">Малын тоо толгой</a></li>
            </ul>
            </li>

            <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="ti-package"></i>
                <span>Хүнс</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(url("/foodProducts/show")); ?>">Гол нэрийн бүтээгдэхүүн</a></li>
                <li><a href="<?php echo e(url("/subProducts/show")); ?>">Орлуулах хүнсний бүтээгдэхүүн</a></li>

            </ul>
            </li>

            <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="ti-pencil-alt"></i>
                <span>ТӨЛӨВЛӨГӨӨ</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(url("/axax/show")); ?>">Авч хэрэгжүүлэх арга хэмжээ</a></li>
            </ul>
            </li>

            <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="ti-widget"></i>
                <span>ТУСЛАХ САН</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(url("/norm/show")); ?>">Хүнсний норм</a></li>
                <li><a href="<?php echo e(url("/status/show")); ?>">Төлөв</a></li>
                <li><a href="<?php echo e(url("/level/show")); ?>">Зэрэгүүд</a></li>
                <li><a href="<?php echo e(url("/org/show")); ?>">Товчилсон нэрийн тайлбар</a></li>
            </ul>
            </li>

            <?php if(Auth::user()->permission == 1): ?>
            <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="ti-user"></i>
                <span>АДМИН ХЭРЭГЛЭГЧ</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(url("/register")); ?>">Админ хэрэглэгч нэмэх</a></li>
                <li><a href="<?php echo e(url("/show/users")); ?>">Админ хэрэглэгч засах</a></li>
            </ul>
            </li>
            <?php endif; ?>

            </ul>
        </div>
        <!-- Sidebar -->
    </div>
    </div>
    <!-- Left Sidebar End -->            <!-- ============================================================== -->
                <!-- Start right Content here -->
                <!-- ============================================================== -->
                <div class="main-content">
                  <div class="page-content">
                    <div class="container-fluid">
                      <?php echo $__env->yieldContent("content"); ?>
                    </div>
                  </div>
                    <!-- container-fluid -->
                </div>
                <!-- End Page-content -->
                <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    © <script>document.write(new Date().getFullYear())</script> <span class="d-none d-sm-inline-block"> Зэвсэгт хүчний Программ хангамжийн төв <i class="mdi text-danger">Лого</i></span>
                </div>
            </div>
        </div>
    </footer>            </div>
                <!-- end main content-->
        </div>
        <!-- END layout-wrapper -->

        <!-- Right Sidebar -->
        <!-- Right Sidebar -->
            <div class="right-bar">
                <div data-simplebar class="h-100">
                    <div class="rightbar-title px-3 py-4">
                        <a href="javascript:void(0);" class="right-bar-toggle float-right">
                            <i class="mdi mdi-close noti-icon"></i>
                        </a>
                        <h5 class="m-0">Settings</h5>
                    </div>

                    <!-- Settings -->
                    <hr class="mt-0" />
                    <h6 class="text-center">Choose Layouts</h6>

                    <div class="p-4">
                        <div class="mb-2">
                            <img src="<?php echo e(url("public/assets/images/layouts/layout-1.jpg")); ?>" class="img-fluid img-thumbnail" alt="">
                        </div>
                        <div class="custom-control custom-switch mb-3">
                            <input type="checkbox" class="custom-control-input theme-choice" id="light-mode-switch" checked />
                            <label class="custom-control-label" for="light-mode-switch">Light Mode</label>
                        </div>

                        <div class="mb-2">
                            <img src="<?php echo e(url("public/assets/images/layouts/layout-2.jpg")); ?>" class="img-fluid img-thumbnail" alt="">
                        </div>
                        <div class="custom-control custom-switch mb-3">
                            <input type="checkbox" class="custom-control-input theme-choice" id="dark-mode-switch" data-bsStyle="assets/css/bootstrap-dark.min.css"
                                data-appStyle="<?php echo e(url("public/uaBCssJs/css/app-dark.min.css")); ?>" />
                            <label class="custom-control-label" for="dark-mode-switch">Dark Mode</label>
                        </div>

                        <div class="mb-2">
                            <img src="<?php echo e(url("public/assets/images/layouts/layout-3.jpg")); ?>" class="img-fluid img-thumbnail" alt="">
                        </div>
                        <div class="custom-control custom-switch mb-5">
                            <input type="checkbox" class="custom-control-input theme-choice" id="rtl-mode-switch" data-appStyle="assets/css/app-rtl.min.css" />
                            <label class="custom-control-label" for="rtl-mode-switch">RTL Mode</label>
                        </div>

                        <a href="https://1.envato.market/grNDB" class="btn btn-primary btn-block mt-3" target="_blank"><i class="mdi mdi-cart mr-1"></i> Purchase Now</a>

                    </div>

                </div> <!-- end slimscroll-menu-->
            </div>
            <!-- /Right-bar -->    <!-- /Right-bar -->

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>

        <!-- JAVASCRIPT -->
        
            <script src="<?php echo e(url("public/uaBCssJs/js/jquery.min.js")); ?>"></script>
            <script src="<?php echo e(url("public/uaBCssJs/js/bootstrap.min.js")); ?>"></script>
            <script src="<?php echo e(url("public/uaBCssJs/js/metismenu.min.js")); ?>"></script>
            <script src="<?php echo e(url("public/uaBCssJs/js/simplebar.min.js")); ?>"></script>
            <script src="<?php echo e(url("public/uaBCssJs/js/node-waves.min.js")); ?>"></script>

            <script src="<?php echo e(url("public/uaBCssJs/sweet-alert/sweetalert2.min.js")); ?>"></script>
            <script src="<?php echo e(url("public/uaBCssJs/sweet-alert/sweet-alerts.init.js")); ?>"></script>

            <script src="<?php echo e(url("public/uaBCssJs/js/app.min.js")); ?>"></script>
              <?php echo $__env->yieldContent('js'); ?>
        </body>
    </html>
<?php /**PATH C:\xampp\htdocs\uabz\resources\views/layouts/layout_master.blade.php ENDPATH**/ ?>