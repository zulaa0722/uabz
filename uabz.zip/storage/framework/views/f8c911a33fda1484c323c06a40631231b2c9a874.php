<?php $__env->startSection('content'); ?>
  <div class="form-row" style="background-color: white; height: 100%; margin-top: 30px;">

    <ol class="rectangle-list col-md-5">
      <li><a href="<?php echo e(url("/reports/population")); ?>" id="pop">Монгол Улсын хүн амын тоо</a></li>
      <li><a href="javascript:void(0)" id="computeTable">Жишсэн хүн амын хэрэгцээг тооцох</a></li>
      
      
    </ol>
    <div id="reportContainer" class="col-md-7">
      <div id="chartPop" style="height:400px;"></div>
      <table id="reportTable" class="table table-striped table-bordered wrap d-none" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
        <thead>
          <tr>
            <th rowspan="2" style="vertical-align:middle;">№</th>
            <th rowspan="2" style="vertical-align:middle;">Хүнсний бүтээгдэхүүний нэр төрөл</th>
            <th rowspan="2" style="vertical-align:middle;">Жишсэн нэг хүний жилийн хүнсний хэрэгцээ /кг/</th>
            <th colspan="<?php echo e(count($pop)); ?>" style="vertical-align:middle;">Жишсэн хүн амын хүнсний хэрэгцээ /мян.тн/</th>
          </tr>
          <tr>

            <?php $__currentLoopData = $pop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <td><?php echo e($val->date); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tr>
        </thead>
        <tbody>
          <?php
            $i=1;
          ?>
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($i++); ?></td>
              <td><?php echo e($product->productName); ?></td>
              <td><?php echo e($product->foodQntt * 365); ?></td>
              <?php $__currentLoopData = $pop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e(round(($val->standardPop*$product->foodQntt*365)/1000,2)); ?></td>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
      </table>
    </div>
  </div>

<style media="screen">

  thead th{
    text-align: center;
  }

  ol{
			counter-reset: li;
			list-style: none;
			*list-style: decimal;
			font: 15px ;
			padding: 0;
			margin-bottom: 4em;
			text-shadow: 0 1px 0 rgba(255,255,255,.5);
		}

		ol ol{
			margin: 0 0 0 2em;
		}
  .rectangle-list a{
    position: relative;
    display: block;
    padding: .4em .4em .4em .8em;
    *padding: .4em;
    margin: .5em 0 .5em 2.5em;
    background: #f6ecda;
    color: #444;
    text-decoration: none;
    transition: all .3s ease-out;
  }

  .rectangle-list a:hover{
    background: #f7e4bf;
  }

  .rectangle-list a:before{
    content: counter(li);
    counter-increment: li;
    position: absolute;
    left: -2.5em;
    top: 50%;
    margin-top: -1em;
    background: #f8ab17;
    height: 2em;
    width: 2em;
    line-height: 2em;
    text-align: center;
    font-weight: bold;
  }

  .rectangle-list a:after{
    position: absolute;
    content: '';
    border: .5em solid transparent;
    left: -1em;
    top: 50%;
    margin-top: -.5em;
    transition: all .3s ease-out;
  }

  .rectangle-list a:hover:after{
    left: -.5em;
    border-left-color: #f8ab17;
  }
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/datatables.min.js")); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/jszip.min.js")); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/pdfmake.min.js")); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/datatables.init.js")); ?>"></script>

  <script type="text/javascript">

  </script>
<script src="<?php echo e(url('public/js/chart/reportPopulation.js')); ?>"></script>
<script src="<?php echo e(url('public/js/chart/jquery.canvasjs.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\uabz\resources\views/Reports/ReportsView.blade.php ENDPATH**/ ?>