<div id="modalUserEdit" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog">
      
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">Хэрэглэгчийн мэдээлэл засах</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
              <form id="frmNewUser" method="POST" action="<?php echo e(route('register')); ?>">
                  <?php echo csrf_field(); ?>

                  <div class="form-group row">
                      <label for="name" class="col-md-4 col-form-label text-md-right">Хэрэглэгчийн нэр:</label>

                      <div class="col-md-6">
                          <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                          <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <span class="invalid-feedback" role="alert">
                                  <strong><?php echo e($message); ?></strong>
                              </span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>

                  <div class="form-group row">
                      <label for="email" class="col-md-4 col-form-label text-md-right">Нэвтрэх цахим хаяг:</label>

                      <div class="col-md-6">
                          <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <span class="invalid-feedback" role="alert">
                                  <strong><?php echo e($message); ?></strong>
                              </span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>

                  <div class="form-group row">
                      <label for="password-confirm" class="col-md-4 col-form-label text-md-right">Хэрэглэгчийн төвшин:</label>

                      <div class="col-md-6">
                          <select class="form-control" id="cmbPermission" name="permission">
                              <option value="0">Сонгоно уу</option>
                              <option value="1">Бүрэн эрх</option>
                              <option value="2">Аймгийн эрх</option>
                              <option value="3">Байгууллагын эрх</option>
                          </select>
                      </div>
                  </div>

                  <div class="form-group row d-none" id="divProvince">
                      <label for="password-confirm" class="col-md-4 col-form-label text-md-right">Аймаг:</label>

                      <div class="col-md-6">
                          <select class="form-control" id="cmbProvince" name="province">
                              <option value="0">Сонгоно уу</option>
                              <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($province->provCode); ?>"><?php echo e($province->provName); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                      </div>
                  </div>

                  <div class="form-group row d-none" id="divOrganization">
                      <label for="password-confirm" class="col-md-4 col-form-label text-md-right">Албан байгууллага:</label>

                      <div class="col-md-6">
                          <select class="form-control" id="cmbOrganization" name="organization">
                              <option value="0">Сонгоно уу</option>
                              <?php $__currentLoopData = $organizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($organization->id); ?>"><?php echo e($organization->fullName); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                      </div>
                  </div>

                  <div class="form-group row mb-0">
                      <div class="col-md-6 offset-md-4">
                          <button post-url="<?php echo e(url('/update/users')); ?>" id="btnUpdateUser" type="submit" class="btn btn-primary">
                              Засах
                          </button>
                      </div>
                  </div>
              </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Хаах</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<?php /**PATH C:\xampp\htdocs\uabz\resources\views/User/userEdit.blade.php ENDPATH**/ ?>