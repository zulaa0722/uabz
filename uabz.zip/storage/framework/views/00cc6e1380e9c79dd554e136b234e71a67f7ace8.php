<style >
   @media  print {
     body{
       visibility: hidden;
     }

     #axaxDB
     {
       width: 100%;
       height: 100%;
       border: solid;
       table-layout: fixed;
       visibility: visible;
     }
     #zailaa
     {
       visibility: visible;
     }
   }
 </style>
<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-12">
      <div class="row">
          <div class="col-xl-12">
              <div class="card">
                <div  class="card-body">
                  <h4 Class="text-center">Авч хэрэгжүүлэх арга хэмжээ</h4>
                  <table id="axaxDB" class="table table-bordered stripe hover cell-border order-column" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                      <thead>
                        <tr class="text-center">
                          <th style="display:none;"></th>
                          <th style="display:none;"></th>
                          <th style="display:none;"></th>
                          <th style="display:none;"></th>
                          <th style="display:none;"></th>
                          <th style="display:none;"></th>
                          <th>№</th>
                          <th>Авч хэрэгжүүлэх <br> арга хэмжээ</th>
                          <th>Зэрэг</th>
                          <th>Ц (Шийдвэр гарсан <br> хугацаа)</th>
                          <th>Төлөв</th>
                          <th>Удирдан зохицуулах <br> байгууллага</th>
                          <th>Дэмжлэг үзүүлэх <br> байгууллага</th>

                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          $j=1;
                        ?>
                          <?php $__currentLoopData = $axaxTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $axaxType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr style="background-color: #ccc; text-align: center;" class="mergedColumn">
                              <td style="display:none;"></td>
                              <td style="display:none;"></td>
                              <td style="display:none;"></td>
                              <td style="display:none;"></td>
                              <td style="display:none;"></td>
                              <td style="display:none;"></td>
                              <td colspan="7"><?php echo e($axaxType->typeName); ?></td>
                              <td style="display:none;"></td>
                              <td style="display:none;"></td>
                              <td style="display:none;"></td>
                              <td style="display:none;"></td>
                              <td style="display:none;"></td>
                              <td style="display:none;"></td>
                            </tr>
                            <?php
                            $axaxes = App\Http\Controllers\AxaxController::getAxaxesByType($axaxType->id);
                            $i=1;
                            ?>
                            <?php $__currentLoopData = $axaxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $axax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr axaxID="<?php echo e($axax->id); ?>">
                                <td style="display:none;"><?php echo e($axax->levelID); ?></td>
                                <td style="display:none;"><?php echo e($axax->statusID); ?></td>
                                <td style="display:none;"><?php echo e($axax->mainOrgID); ?></td>
                                <td style="display:none;"><?php echo e($axax->typeID); ?></td>
                                <td style="display:none;"><?php echo e($axax->supportOrg); ?></td>
                                <td style="display:none;"><?php echo e($axax->id); ?></td>
                                <?php if($i < 10): ?>
                                  <td>2.<?php echo e($j); ?>.0<?php echo e($i); ?></td>
                                <?php else: ?>
                                  <td>2.<?php echo e($j); ?>.<?php echo e($i); ?></td>
                                <?php endif; ?>
                                <td><?php echo e($axax->axaxName); ?></td>
                                <td><?php echo e($axax->levelName); ?></td>
                                <td><?php echo e($axax->inTime); ?></td>
                                <td><?php echo e($axax->statusName); ?></td>
                                <td><?php echo e($axax->abbrName); ?></td>
                                <td><?php echo e($axax->supportOrgNames); ?></td>
                              </tr>
                              <?php
                                $i++;
                              ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php
                              $j++;
                            ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tr>
                      </tbody>
                    </table>
                    <button class="btn btn-primary" type="button" name="button" id="btnAddModalOpen">Нэмэх</button>
                    <button class="btn btn-warning" type="button" name="button" id="btnEditModalOpen">Засах</button>
                    <button class="btn btn-danger" type="button" name="button" id="btnAxaxDelete">Устгах</button>
                  </div>
                </div>
            </div>
        </div>
      </div>
    </div>

<?php echo $__env->make('Axax.AxaxNew', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Axax.AxaxEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url("public/uaBCssJs/datatableCss/datatables.min.css")); ?>">
  <style media="screen">
      #axaxDB tbody tr.selected {
        color: white;
        background-color: #8893f2;
      }
      #axaxDB tbody tr{
        cursor: pointer;
      }
      #axaxDB .mergedColumn{
        cursor: default;
      }


      /* #zailaa
      {
        visibility: visible;
      } */
    }

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/datatables.min.js")); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/jszip.min.js")); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/pdfmake.min.js")); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/datatables.init.js")); ?>"></script>

  <script type="text/javascript">
  var dataRow = "";
  var table = "";
  var csrf = "<?php echo e(csrf_token()); ?>";
  var getAxax = "<?php echo e(url("/getAxax")); ?>";
  var axaxNew = "<?php echo e(url("/axax/insert")); ?>";
  var axaxEditUrl = "<?php echo e(url("/axax/edit")); ?>";
  var axaxDeleteUrl = "<?php echo e(url("/axax/delete")); ?>";

  // table = $('#axaxDB').DataTable();

  $(document).ready(function(){

     table = $('#axaxDB').DataTable({
      "language": {
              "lengthMenu": "_MENU_ мөрөөр харах",
              "zeroRecords": "Хайлт илэрцгүй байна",
              "info": "Нийт _PAGES_ -аас _PAGE_-р хуудас харж байна ",
              "infoEmpty": "Хайлт илэрцгүй",
              "infoFiltered": "(_MAX_ мөрөөс хайлт хийлээ)",
              "sSearch": "Хайх: ",
              "paginate": {
                "previous": "Өмнөх",
                "next": "Дараахи"
              },
              "select": {
                  rows: ""
              }
          },
          "select": {style : 'single' },
          "stateSave": true,
          // "ordering": false,
          "order": [[6, 'asc']],
           "columnDefs": [{
              "targets": "_all",
              "orderable": false
           }],
          "columns": [
            { data: "levelID", name: "levelID", visible: false},
            { data: "statusID", name: "statusID", visible: false},
            { data: "mainOrgID", name: "mainOrgID", visible: false},
            { data: "axaxTypeID", name: "axaxTypeID", visible: false},
            { data: "supportOrg", name: "supportOrg", visible: false},
            { data: "id", name: "id", visible: false},
            { data: "number", name: "number"},
            { data: "axaxName", name: "axaxName"},
            { data: "levelName", name: "levelName"},
            { data: "inTime", name: "inTime"},
            { data: "statusName", name: "statusName"},
            { data: "mainName", name: "mainName"},
            { data: "supportName", name: "supportName"}
            ]
        });
        // table.order( [ 5, 'asc' ] ).draw();

        $('#axaxDB tbody').on( 'click', 'tr', function () {
          if ( $(this).hasClass('selected') ) {
              $(this).removeClass('selected');
              dataRow = "";
          }else {
            $('#axaxDB tbody tr').removeClass('selected');
              $(this).addClass('selected');
              var currow = $(this).closest('tr');
              // alert($(this).attr("axaxID"));
              dataRow = $('#axaxDB').DataTable().row(currow).data();
          }
          });
  });
  </script>

<script src="<?php echo e(url("public/js/Axax/AxaxNew.js")); ?>"></script>
<script src="<?php echo e(url("public/js/Axax/AxaxEdit.js")); ?>"></script>
<script src="<?php echo e(url("public/js/Axax/AxaxDelete.js")); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\uabz\resources\views/Axax/Axax.blade.php ENDPATH**/ ?>