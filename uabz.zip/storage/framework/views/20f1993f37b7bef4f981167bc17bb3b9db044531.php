<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-12">

        <div class="card">
          <div  class="card-body">
            <h4 Class="text-center">Хүнсний бүтээгдэхүүн</h4>
            <table id="foodProductsDB" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                <thead>
                  <tr>
                    <th>№</th>
                    <th>Хүнсний нэр</th>
                    <th>Тоо хэмжээ</th>
                    <th>Уураг</th>
                    <th>Тос</th>
                    <th>Нүүрс ус</th>
                    <th>ккал</th>
                    <th>Бодогдсон ккал</th>
                    <th>Үнэ</th>
                  </tr>
                </thead>
                <tbody>
                  <td></td>
                </tbody>
              </table>
              <button class="btn btn-primary" type="button" name="button" id="btnAddModalOpen">Нэмэх</button>
              <button class="btn btn-warning" type="button" name="button" id="btnEditModalOpen">Засах</button>
              <button class="btn btn-danger" type="button" name="button" id="btnFoodProductsDelete">Устгах</button>
            </div>
          </div>
      </div>
    </div>
<?php echo $__env->make('FoodProducts.FoodProductsNew', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('FoodProducts.FoodProductsEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url("public/uaBCssJs/datatableCss/datatables.min.css")); ?>">
  <style media="screen">
#foodProductsDB tbody tr.selected {
  color: white;
  background-color: #8893f2;
}
#foodProductsDB tbody tr{
  cursor: pointer;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/datatables.min.js")); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/jszip.min.js")); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/pdfmake.min.js")); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/datatables.init.js")); ?>"></script>

  <script type="text/javascript">
  var dataRow = "";
  var table = "";
  var csrf = "<?php echo e(csrf_token()); ?>";
  var getFoodProducts = "<?php echo e(url("/getFoodProducts")); ?>";
  var foodProductsNew = "<?php echo e(url("/foodProducts/insert")); ?>";
  var foodProductsEditUrl = "<?php echo e(url("/foodProducts/edit")); ?>";
  var foodProductsDeleteUrl = "<?php echo e(url("/foodProducts/delete")); ?>";

  $(document).ready(function(){
     table = $('#foodProductsDB').DataTable({
      "language": {
              "lengthMenu": "_MENU_ мөрөөр харах",
              "zeroRecords": "Хайлт илэрцгүй байна",
              "info": "Нийт _PAGES_ -аас _PAGE_-р хуудас харж байна ",
              "infoEmpty": "Хайлт илэрцгүй",
              "infoFiltered": "(_MAX_ мөрөөс хайлт хийлээ)",
              "sSearch": "Хайх: ",
              "paginate": {
                "previous": "Өмнөх",
                "next": "Дараахи"
              },
              "select": {
                  rows: ""
              }
          },
          select: {
            style: 'single'
          },
          "processing": true,
          "serverSide": true,
          "stateSave": true,
          "ajax":{
                   "url": getFoodProducts,
                   "dataType": "json",
                   "type": "post",
                   "data":{
                        _token: csrf
                      }
                 },
          "columns": [
            { data: "id", name: "id",  render: function (data, type, row, meta) {
              return meta.row + meta.settings._iDisplayStart + 1;
            }},
            { data: "productName", name: "productName"},
            { data: "foodQntt", name: "foodQntt"},
            { data: "foodProtein", name: "foodProtein"},
            { data: "foodFat", name: "foodFat"},
            { data: "foodCarbon", name: "foodCarbon"},
            { data: "foodCkal", name: "foodCkal"},
            { data: "foodTomCkal", name: "foodTomCkal"},
            { data: "price", name: "price"}
            ]
        });

        $('#foodProductsDB tbody').on( 'click', 'tr', function () {
          if ( $(this).hasClass('selected') ) {
              $(this).removeClass('selected');
              dataRow = "";
          }else {
              table.$('tr.selected').removeClass('selected');
              $(this).addClass('selected');
              var currow = $(this).closest('tr');
              dataRow = $('#foodProductsDB').DataTable().row(currow).data();
          }
          });
  });
  </script>

<script src="<?php echo e(url("public/js/FoodProducts/FoodProductsNew.js")); ?>"></script>
<script src="<?php echo e(url("public/js/FoodProducts/FoodProductsEdit.js")); ?>"></script>
<script src="<?php echo e(url("public/js/FoodProducts/FoodProductsDelete.js")); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\uabz\resources\views/FoodProducts/FoodProducts.blade.php ENDPATH**/ ?>