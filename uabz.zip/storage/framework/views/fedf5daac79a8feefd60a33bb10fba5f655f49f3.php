<div id="modalFoodReserveNew" class="modal fade bs-example-modal-xl" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-xl" role="document">
      
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">Хүнсний нөөцийн судалгаа нэмэх</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
              <form id="frmFoodReserveNew" action="" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group row justify-content-center">
                    <label id="provName" style="color:blue; font-size:16px;"> </label>
                    <label style="font-size:16px;">&nbsp аймгийн &nbsp</label>
                    <label style="color:blue; font-size:16px;" id="symName"></label>
                    <label style="font-size:16px;">&nbsp сум </label>
                </div>
                  <div class="form-group row">
                  <div class="col-md-3">
                    <label>Огноо:</label>
                    <input type="date" name="foodReserveDate" id="foodReserveDate" value="" class="form-control">
                  </div>
                </div>

                <div class="form-group row">

                  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                      <label style="margin-bottom:-20px;"><?php echo e($product->productName); ?></label><label style="color:red;font-style:bold;">&nbsp /кг/</label>
                      <input class="form-control foodProductFields" type="number" id="<?php echo e($product->id); ?>" name="<?php echo e($product->productName); ?>"
                        foodQntt="<?php echo e($product->foodQntt); ?>" foodKcal="<?php echo e($product->foodCkal); ?>">
                      <label style="margin-bottom: 20px; font-size:12px;color:#400513">Нийт Ккал: &nbsp</label><label id="foodTotalKcal<?php echo e($product->id); ?>">&nbsp</label>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="clearfix"></div>


            <div class="modal-footer">
                <button type="submit" id="btnFoodReserveAdd" class="btn btn-primary">Хадгалах</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Хаах</button>
            </div>
            </form>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<?php /**PATH C:\xampp\htdocs\uabz\resources\views/FoodReserve/FoodReserveNew.blade.php ENDPATH**/ ?>