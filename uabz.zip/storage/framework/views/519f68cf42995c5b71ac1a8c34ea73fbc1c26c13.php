<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(url("public/uaBCssJs/datatableCss/datatables.min.css")); ?>">
<link href="<?php echo e(url('public/uaBCssJs/dropzone/dropzone.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-12">
        <div class="card">
          <div id="changeBlade" class="card-body">
            <h4 class="text-center">Гол нэрийн бүтээгдэхүүн дуусч буй сумд</h4>
            <table id="ShowSubProducts" class="table table-striped table-bordered wrap " style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                <thead>
                  <tr>
                    <th>№</th>
                    <th></th>
                    <th>Аймаг, нийслэл</th>
                    <th></th>
                    <th style="width:18%;">Сум, Дүүрэг</th>
                    <th></th>
                    <th>Гол нэрийн бүтээгдэхүүн</th>
                    <th>Үлдсэн хоног</th>
                    <th>Арга хэмжээ</th>
                    

                  </tr>
                </thead>
                <tbody>
                  <form id="showCompanySubsForm" action="" method="post">

                  <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td></td>
                      <td><?php echo e($val["provID"]); ?></td>
                      <td><?php echo e($val["provName"]); ?></td>
                      <td><?php echo e($val["symID"]); ?></td>
                      <td><?php echo e($val["symName"]); ?></td>
                      <td><?php echo e($val["productID"]); ?></td>
                      <td><?php echo e($val["product"]); ?></td>
                      <td class="text-danger"><?php echo e($val["leftDays"]); ?></td>
                      <td>
                        <input id="showSub" type="button" class="btn btn-warning showSubProducts" name="" value="Орлуулах"
                          provID=<?php echo e($val["provID"]); ?> symID=<?php echo e($val["symID"]); ?> productID=<?php echo e($val["productID"]); ?>

                          provName="<?php echo e($val["provName"]); ?>" symName="<?php echo e($val["symName"]); ?>" product="<?php echo e($val["product"]); ?>">
                      </td>
                      
                    </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </form>
                </tbody>
            </table>
            <?php echo $__env->make('ShowSubProduct.ShowCompanySubs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/datatables.min.js")); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/jszip.min.js")); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/pdfmake.min.js")); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/datatables.init.js")); ?>"></script>

  <script type="text/javascript">
    var dataRow = "";
    var showCompanySubs = "<?php echo e(url("/SubReserveController/showCompanySubs")); ?>";
    var saveSubs = "<?php echo e(url("SubReserveController/saveSubProducts")); ?>";
    var editNorm = "<?php echo e(url("/SubReserveController/editNorm")); ?>"
    var table = "";
  </script>



<script type="text/javascript">
$(document).ready(function(){

  table = $('#ShowSubProducts').DataTable( {
    "language": {
            "lengthMenu": "_MENU_ мөрөөр харах",
            "zeroRecords": "Хайлт илэрцгүй байна",
            "info": "Нийт _PAGES_ -аас _PAGE_-р хуудас харж байна ",
            "infoEmpty": "Хайлт илэрцгүй",
            "infoFiltered": "(_MAX_ мөрөөс хайлт хийлээ)",
            "sSearch": "Хайх: ",
            "paginate": {
                        "previous": "Өмнөх",
                        "next": "Дараахи"
                        },
            "select": {
                      rows: ""
                      }
            },
      select: {
        style: 'single'
      },
      "orderCellsTop": true,
      "fixedHeader": true,
      "scrollX": true,
      "stateSave": true,
      "columns": [
        {
          data: "id", name: "id",  render: function (data, type, row, meta) {
            return meta.row + meta.settings._iDisplayStart + 1;
          }
        },
        { data: "provID", name: "provID", visible: false},
        { data: "provName", name: "provName"},
        { data: "symID", name: "symID", visible: false},
        { data: "symName", name: "symName"},
        { data: "productID", name: "productID", visible: false},
        { data: "product", name: "product"},
        { data: "leftDays", name: "leftDays"},
        { data: "action1", name: "action1"},
        // { data: "action", name: "action"},

      ]
    });

});
</script>
<script src="<?php echo e(url('public/js/mongolianMap/ShowSubProduct.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\uabz\resources\views/ShowSubProduct/ShowSubProducts.blade.php ENDPATH**/ ?>