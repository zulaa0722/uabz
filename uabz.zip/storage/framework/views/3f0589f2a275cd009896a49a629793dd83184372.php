<div id="modalNormNew" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-xl">
      
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">Норм нэмэх</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
              <form id="frmSectorNew" action="" method="post">
                  <div class="row">
                    <div class="col-md-3">
                        <label>Нормын нэр:</label>
                    </div>
                    <div class="col-md-3">
                        <input class="form-control" type="text" name="normName" id="txtNormName" value="">
                    </div>
                  </div>
                  <div class="row">
                    <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col-md-3">
                          <label><?php echo e($food->productName); ?> /кг/</label>
                          <input type="number" foodQntt="<?php echo e($food->foodQntt); ?>" kcal="<?php echo e($food->foodCkal); ?>" foodID="<?php echo e($food->id); ?>" class="form-control txtProductQtt" name="" value="" placeholder="Тоо хэмжээ">
                          <input type="hidden" class="form-control" id="product_kcal<?php echo e($food->id); ?>" name="" value="" placeholder="0">
                          <label for="">Ккал: </label><label id="lblKcal<?php echo e($food->id); ?>" for="">0</label>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                  <div class="row">
                      <h5 class="text-center"><label for="">Нийт ккал: </label><label id="lblAllKcal" for="">0</label></h5>
                      <input type="hidden" class="form-control" id="hideSumKcal" name="" value="0">
                  </div>
              </form>
            </div>
            <div class="modal-footer">
                <button type="button" id="btnNormAdd" post-url="<?php echo e(url("/norm/new")); ?>" class="btn btn-primary">Хадгалах</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Хаах</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<?php /**PATH C:\xampp\htdocs\uabz\resources\views/Norm/normNew.blade.php ENDPATH**/ ?>