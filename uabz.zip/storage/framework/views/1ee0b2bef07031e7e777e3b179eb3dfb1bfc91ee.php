

<div id="modalAxaxNew" class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
      
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">Авч хэрэгжүүлэх арга хэмжээ нэмэх</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
              <?php echo csrf_field(); ?>
              <form id="frmAxaxNew" action="" method="post">
                <div class="form-group row">
                  <div class="col-md-6">
                    <label>Хэрэгжүүлэх арга хэмжээний чиглэл:</label>
                    <select class="form-control" id="axaxTypeID" name="axaxTypeID">
                        <option value="-1">Сонгоно уу</option>
                      <?php $__currentLoopData = $axaxTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $axaxType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                          $axaxCount = App\Http\Controllers\AxaxController::getAxaxCountByType($axaxType->id);
                        ?>
                        <option axaxCount="<?php echo e($axaxCount); ?>" value="<?php echo e($axaxType->id); ?>"><?php echo e($axaxType->typeName); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-md-12">
                    <label>Хэрэгжүүлэх арга хэмжээ:</label>
                      <textarea class="form-control" id="axaxName" name="axaxName" rows="4"></textarea>
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-md-6">
                    <label>Ц (Шийдвэр гарсан хугацаа) + (хоног:цаг):</label>
                    <input type="text" class="form-control" id="inTime" name="inTime"></textarea>
                  </div>
                  <div class="col-md-3">
                    <label>Төлөв:</label>
                    <select class="form-control" id="statusID" name="statusID">
                        <option value="-1">Сонгоно уу</option>
                      <?php $__currentLoopData = $statuss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status->id); ?>"><?php echo e($status->statusName); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <div class="col-md-3">
                    <label>Зэрэг:</label>
                    <select class="form-control" id="levelID" name="levelID">
                        <option value="-1">Сонгоно уу</option>
                      <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($level->id); ?>"><?php echo e($level->levelName); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>

                <div class="clearfix"></div>
                <div class="form-group row">
                  <div class="col-md-6">
                    <label>Удирдан зохицуулах байгууллага</label>
                    <select class="form-control" name="mainOrgID" id="mainOrgID">
                        <option value="-1">Сонгоно уу</option>
                      <?php $__currentLoopData = $organizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($organization->id); ?>"><?php echo e($organization->abbrName); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <div class="col-md-6">
                    <label>Тайлбар:</label>
                    <textarea class="form-control" id="comment" name="comment"></textarea>
                  </div>
                </div>
              </form>
                <div class="col-md-12">
                  <label>Дэмжлэг үзүүлэх байгууллагууд:</label><br>
                  <?php $__currentLoopData = $organizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="form-check-label">
                      <input type="checkbox" class="supportOrgs" name="<?php echo e($organization->abbrName); ?>" id="" value="<?php echo e($organization->id); ?>">&nbsp;<?php echo e($organization->abbrName); ?>&nbsp;&nbsp;&nbsp;
                    </label>
                    
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" id="btnAxaxAdd" class="btn btn-primary">Хадгалах</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Хаах</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<?php /**PATH C:\xampp\htdocs\uabz\resources\views/Axax/AxaxNew.blade.php ENDPATH**/ ?>