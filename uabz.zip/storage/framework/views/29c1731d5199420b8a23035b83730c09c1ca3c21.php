<?php $__env->startSection('content'); ?>
  <div class="p-3 mb-2 bg-danger text-white">Энэ хэсэгт хандах эрхгүй байна!!!</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\uabz\resources\views/permission/permissionError.blade.php ENDPATH**/ ?>