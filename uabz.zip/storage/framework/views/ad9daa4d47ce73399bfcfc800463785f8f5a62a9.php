<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(url("public/uaBCssJs/datatableCss/datatables.min.css")); ?>">
<link href="<?php echo e(url('public/uaBCssJs/dropzone/dropzone.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-12">
        <div class="card">
          <div class="card-body">
            <div class="row col-md-12">
              <div class="col-md-3">
                <label>Аймаг аа сонгоно уу.</label>
                <select class="form-control" id="cmbProv" name="" post-url="<?php echo e(url("/get/dangered/syms/by/provID")); ?>">
                  <option value="-1"> Сонгоно уу</option>
                  <?php $__currentLoopData = $provs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($prov->provID); ?>"><?php echo e($prov->provName); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="col-md-3 d-none" id="showSymDiv">
                <label>Сум аа сонгоно уу.</label>
                <select class="form-control" id="cmbSym" name="">
                </select>
              </div>
            </div>

            <h4 class="text-center col-md-12" style="margin-top:20px;">
              <label style="font-size: 22px; font-weight: bold;" id="lblProv"></label>&nbsp
              <label style="font-size: 22px; font-weight: bold;" id="lblSym"></label></h4>
            <h4 class="text-center col-md-12">Гол нэрийн хүнсний бүтээгдэхүүний зарцуулалт</h4>
            <table post-url="<?php echo e(url("/log/foodReserve/refresh")); ?>" id="remainingProducts" class="table table-striped wrap table-bordered" style="width: 100%;">
              <thead>
                <th>id</th>
                <th>№</th>
                <th>Огноо</th>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <th class="text-center"><?php echo e($product->productName); ?> /кг/</th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </thead>
              <tbody>

              </tbody>
            </table>
            <div class="row col-md-12">

              <button class="btn btn-primary" type="button" id="btnShowSpentModal" urlProducts="<?php echo e(url("/log/foodReserve/showRemainingProducts")); ?>">Зарцуулалт оруулах</button>
              <button class="btn btn-danger" type="button" id="btnDeleteSpent" deleteSpentUrl="<?php echo e(url("/log/foodReserve/deleteRemainingProducts")); ?>">Устгах</button>

            </div>
          </div>
        </div>
    </div>
  </div>

<?php echo $__env->make('LogFoodReserve.LogFoodReserveNew', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/datatables.min.js")); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/jszip.min.js")); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/pdfmake.min.js")); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url("public/uaBCssJs/datatableJs/datatables.init.js")); ?>"></script>
  <script type="text/javascript">
    var cols1 = <?php echo json_encode($products); ?>;
    var dataRow = "";

  </script>

  <script src="<?php echo e(url("public/js/LogFoodReserve/log_ReserveShow.js")); ?>"></script>
  <script src="<?php echo e(url("public/js/LogFoodReserve/log_ReserveEdit.js")); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\uabz\resources\views/LogFoodReserve/LogFoodReserve.blade.php ENDPATH**/ ?>