<div id="modalNormEdit" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-xl">
      
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">Норм засах</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
              <form id="frmSectorNew" action="" method="post">
                  <div class="row">
                    <div class="col-md-3">
                    </div>
                    <div class="col-md-6">
                        <h4 class="text-center"><strong><label id="lblEditNormName"></label></strong></h4>
                    </div>
                  </div>
                  <div class="row">
                    <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col-md-3">
                          <label><?php echo e($food->productName); ?> /кг/</label>
                          <input type="number" id="editProductID<?php echo e($food->id); ?>" foodQntt="<?php echo e($food->foodQntt); ?>" kcal="<?php echo e($food->foodCkal); ?>" foodID="<?php echo e($food->id); ?>" class="form-control txtEditProductQtt" name="" value="" placeholder="Тоо хэмжээ">
                          <input type="hidden" class="form-control" id="editProduct_kcal<?php echo e($food->id); ?>" name="" value="" placeholder="0">
                          <label for="">Ккал: </label><label id="lblEditKcal<?php echo e($food->id); ?>" for="">0</label>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                  <div class="row">
                      <h5 class="text-center"><label for="">Нийт ккал: </label><label id="lblEditAllKcal" for="">0</label></h5>
                      <input type="hidden" class="form-control" id="hideEditSumKcal" name="" value="0">
                  </div>
              </form>
            </div>
            <div class="modal-footer">
                <button type="button" id="btnNormEdit" post-url="<?php echo e(url("/norm/update")); ?>" class="btn btn-primary">Засах</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Хаах</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<?php /**PATH C:\xampp\htdocs\uabz\resources\views/Norm/normEdit.blade.php ENDPATH**/ ?>