<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DangerSym extends Model
{
    protected $table = 'tb_danger_sym';
    public $primaryKey = 'id';
    public $timestamps = false;
}
