<?php

namespace App;

class ConstantVariables
{
    // public $sheepKG = 18.7;
    const sheepKG = 18.7;

    const greenDay = 60; /*60 aas deeshee*/
    const yellow = 60; /*60 aas doosh bol shar*/
    const orange = 29; /*29 uus doosh bol ulbar shar*/
    const redDay = 15; /*15 aas doosh bol ulaan*/
}
