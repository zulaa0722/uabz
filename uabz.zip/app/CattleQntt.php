<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CattleQntt extends Model
{
  protected $table = 'tb_cattle_qntt';
  public $primaryKey = 'id';
  public $timestamps = false;

  public function getLastInsertedDate(){
    
  }
}
